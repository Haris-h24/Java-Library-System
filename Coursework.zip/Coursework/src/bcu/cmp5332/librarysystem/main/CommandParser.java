package bcu.cmp5332.librarysystem.main;

import bcu.cmp5332.librarysystem.commands.*;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;

public class CommandParser {

    public static <Books> Command parse(Library library, String line) throws IOException, LibraryException {
        try {
            String[] parts = line.split(" ", 3);
            String cmd = parts[0];

            if (cmd.equals("addbook")) {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Title: ");
                String title = br.readLine();
                System.out.print("Author: ");
                String author = br.readLine();
                System.out.print("Publication Year: ");
                String publicationYear = br.readLine();
                System.out.print("Publisher: ");
                String publisher = br.readLine();
                return new AddBook(title, author, publicationYear, publisher);

            } else if (cmd.equals("addpatron")) {
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Name: ");
                String name = br.readLine();
                System.out.print("Phone: ");
                String phone = br.readLine();
                System.out.print("Email: ");
                String email = br.readLine();

                ArrayList<Book> books = new ArrayList<>();
                return new AddPatron(name, phone, email, books);
            } else if (cmd.equals("hidebook")) { // User enters id and a response
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                System.out.print("Enter ID: ");
                int id = Integer.parseInt(br.readLine());
                System.out.print("Hide? y/n: ");
                String hideStr = br.readLine();

                boolean hide = hideStr.equalsIgnoreCase("y");
                if (hide) {
                    return new HideBook(id); // hide = isHidden, false = isDeleted
                } else {
                    System.out.println("No book was hidden.");
                    return null; // or handle it accordingly in your program
                }
            } else if (cmd.equals("hidepatron")) { // User enters id and a response
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                System.out.print("Enter ID: ");
                int id = Integer.parseInt(br.readLine());
                System.out.print("Hide? y/n: ");
                String hideStr = br.readLine();

                boolean hide = hideStr.equalsIgnoreCase("y");
                if (hide) {
                    return new HidePatron(id); 
                } else {
                    System.out.println("No patron was hidden.");
                    return null; // or handle it accordingly in your program
                }

            } else if (cmd.equals("loadgui")) {
                return new LoadGUI();
            } else if (parts.length == 1) {
                if (line.equals("listbooks")) {
                    return new ListBooks();
                } else if (line.equals("listpatrons")) {
                    return new ListPatrons();
                } else if (line.equals("help")) {
                    return new Help();
                }
            } else if (parts.length == 2) {
                int id = Integer.parseInt(parts[1]);

                if (cmd.equals("showbook")) {
                    Book book = library.getBookByID(id);
                    return new ShowBook(book.getId());
                } else if (cmd.equals("showpatron")) {
                    Patron patron = library.getPatronByID(id);
                    return new ShowPatron(patron.getId());
                }
            } else if (parts.length == 3) {
                int patronID = Integer.parseInt(parts[1]);
                int bookID = Integer.parseInt(parts[2]);

                if (cmd.equals("borrow")) {
                    Book book = library.getBookByID(bookID);
                    Patron patron = library.getPatronByID(patronID);

                    LocalDate startDate = LocalDate.now();
                    LocalDate dueDate = startDate.plusDays(library.getLoanPeriod());

                    return new BorrowBook(library, patron, book, startDate, dueDate);
                } else if (cmd.equals("renew")) { // If user inputs renew, it will get the necessary parameters
                    Book book = library.getBookByID(bookID);
                    Patron patron = library.getPatronByID(patronID);

                    LocalDate startDate = LocalDate.now();
                    LocalDate dueDate = startDate.plusDays(library.getLoanPeriod());

                    return new RenewBook(library, patron, book, startDate, dueDate); // Returns new renew book object
                } else if (cmd.equals("return")) { // If user inputs return, it will get the necessary parameters
                    Book book = library.getBookByID(bookID);
                    Patron patron = library.getPatronByID(patronID);

                    return new ReturnBook(patron, book); // Returns new return book object
                }
            }
        } catch (NumberFormatException ex) {
            // Print or log the exception for debugging purposes
            ex.printStackTrace();
        }
        throw new LibraryException("Invalid command.");
    }
}
