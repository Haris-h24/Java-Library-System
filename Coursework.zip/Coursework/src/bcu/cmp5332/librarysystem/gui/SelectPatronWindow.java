package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.commands.ShowPatron;
import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * The window for selecting and displaying details of a specific patron.
 */
public class SelectPatronWindow extends JFrame implements ActionListener {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    // Reference to the main window
    private MainWindow mw;

    // Text field for user input (patron ID)
    private JTextField idText = new JTextField();

    // Buttons for selecting and canceling patron selection
    private JButton selectBtn = new JButton("Select");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructor for SelectPatronWindow.
     * 
     * @param mw The reference to the main window.
     */
    public SelectPatronWindow(MainWindow mw) {
        this.mw = mw;
        initialize(); // Linking to the main window
    }

    /**
     * Initializes the contents of the frame.
     */
    private void initialize() {
        // Set the look and feel to the system's default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle any exceptions related to setting look and feel
        }

        setTitle("Select a patron");

        // Set the size of the window
        setSize(300, 200);

        // Create top panel with input field for patron ID
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));
        topPanel.add(new JLabel("ID : "));
        topPanel.add(idText);

        // Create bottom panel with buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(selectBtn);
        bottomPanel.add(cancelBtn);

        // Add action listeners to buttons
        selectBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        // Set layout for the window and add panels
        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // Set window location relative to the main window
        setLocationRelativeTo(mw); // Creating the SelectPatronWindow

        // Make the window visible
        setVisible(true);
    }

    /**
     * Handles action events for buttons.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == selectBtn) {
            showPatron();
        } else if (ae.getSource() == cancelBtn) {
            // Close the window when cancel is clicked
            this.setVisible(false);
        }
    }

    /**
     * Displays details of a specific patron based on user input (patron ID).
     */
    private void showPatron() {
        try {
            // Get patron ID from the text field
            String id = idText.getText();
            int identity = Integer.parseInt(id);

            // Create and execute the ShowPatron Command
            Command showPatron = new ShowPatron(identity);
            showPatron.execute(mw.getLibrary(), LocalDate.now());

            // Refresh the view with the specific patron details within the table
            mw.displayViewBook(identity);

            // Hide (close) the SelectPatronWindow
            this.setVisible(false);
        } catch (LibraryException ex) {
            // Display an error message if a library exception occurs
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   
    public Library getLibrary() {
        return this.mw.getLibrary();
    }
}
