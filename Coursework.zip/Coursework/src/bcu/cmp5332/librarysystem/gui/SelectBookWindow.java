package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.commands.ShowBook;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * The window for selecting and displaying details of a specific book.
 */
public class SelectBookWindow extends JFrame implements ActionListener {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    // Reference to the main window
    private MainWindow mw;

    // Text field for user input (book ID)
    private JTextField idText = new JTextField();

    // Buttons for selecting and canceling book selection
    private JButton selectBtn = new JButton("Select");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructor for SelectBookWindow.
     * 
     * @param mw The reference to the main window.
     */
    public SelectBookWindow(MainWindow mw) {
        this.mw = mw;
        initialize(); // Linking to the main window
    }

    /**
     * Initializes the contents of the frame.
     */
    private void initialize() {
        // Set the look and feel to the system's default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle any exceptions related to setting look and feel
        }

        setTitle("Select a book");

        // Set the size of the window
        setSize(300, 200);

        // Create top panel with input field for book ID
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));
        topPanel.add(new JLabel("ID : "));
        topPanel.add(idText);

        // Create bottom panel with buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(selectBtn);
        bottomPanel.add(cancelBtn);

        // Add action listeners to buttons
        selectBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        // Set layout for the window and add panels
        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // Set window location relative to the main window
        setLocationRelativeTo(mw); // Creating select book window

        // Make the window visible
        setVisible(true);
    }

    /**
     * Handles action events for buttons.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == selectBtn) {
            showBooks();
        } else if (ae.getSource() == cancelBtn) {
            // Close the window when cancel is clicked
            this.setVisible(false);
        }
    }

    /**
     * Displays details of a specific book based on user input (book ID).
     */
    private void showBooks() {
        try {
            // Get book ID from the text field
            String id = idText.getText();
            int identity = Integer.parseInt(id);

            // Create and execute the ShowBook Command
            Command showBook = new ShowBook(identity);
            showBook.execute(mw.getLibrary(), LocalDate.now());

            // Refresh the view with the specific book within the table
            mw.displayViewPatron(identity);

            // Hide (close) the SelectBookWindow
            this.setVisible(false);
        } catch (LibraryException ex) {
            // Display an error message if a library exception occurs
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    public Library getLibrary() {
        return this.mw.getLibrary();
    }
}
