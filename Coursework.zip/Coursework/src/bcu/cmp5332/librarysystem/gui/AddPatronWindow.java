package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.commands.AddPatron;
import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * The window for adding a new patron to the library.
 */
public class AddPatronWindow extends JFrame implements ActionListener {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    // Reference to the main window
    private MainWindow mw;

    // Text fields for user to add patron
    private JTextField nameText = new JTextField();
    private JTextField phoneText = new JTextField();
    private JTextField emailText = new JTextField();

    // Buttons for adding and canceling patron addition
    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructor for AddPatronWindow.
     * 
     * @param mw The reference to the main window.
     */
    public AddPatronWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the contents of the frame.
     */
    private void initialize() {
        // Set the look and feel to the system's default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle any exceptions related to setting look and feel
        }

        setTitle("Add a New Patron");

        // Set the size of the window
        setSize(300, 200);

        // Create top panel with input fields
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));
        topPanel.add(new JLabel("Name : "));
        topPanel.add(nameText);
        topPanel.add(new JLabel("Phone : "));
        topPanel.add(phoneText);
        topPanel.add(new JLabel("Email : "));
        topPanel.add(emailText);

        // Create bottom panel with buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        // Add action listeners to buttons
        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        // Set layout for the window and add panels
        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // Set window location relative to main window
        setLocationRelativeTo(mw);

        // Make the window visible
        setVisible(true);
    }

    /**
     * Handles action events for buttons.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            addPatron();
        } else if (ae.getSource() == cancelBtn) {
            // Close the window when cancel is clicked
            this.setVisible(false);
        }
    }

    /**
     * Adds a new patron to the library based on user input.
     */
    private void addPatron() {
        try {
            // Get user input from text fields
            String name = nameText.getText();
            String phone = phoneText.getText();
            String email = emailText.getText();
            List<Book> books = new ArrayList<>();

            // Create and execute the AddPatron Command
            Command addPatron = new AddPatron(name, phone, email, books);
            addPatron.execute(mw.getLibrary(), LocalDate.now());

            // Refresh the view with the list of patrons in the main window
            mw.displayPatrons();

            // Hide (close) the AddPatronWindow
            this.setVisible(false);
        } catch (LibraryException ex) {
            // Display an error message if library exception occurs
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
