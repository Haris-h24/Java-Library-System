package bcu.cmp5332.librarysystem.gui;

import bcu.cmp5332.librarysystem.commands.AddBook;
import bcu.cmp5332.librarysystem.commands.Command;
import bcu.cmp5332.librarysystem.main.LibraryException;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * The window for adding a new book to the library.
 */
public class AddBookWindow extends JFrame implements ActionListener {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    // Reference to the main window
    private MainWindow mw;

    // Text fields for users to add a book
    private JTextField titleText = new JTextField();
    private JTextField authText = new JTextField();
    private JTextField pubDateText = new JTextField();
    private JTextField publisherText = new JTextField();

    // Buttons for adding and canceling new book addition
    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructor for AddBookWindow.
     * 
     * 
     */
    public AddBookWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the contents of the frame.
     */
    private void initialize() {
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle any exceptions related to setting look and feel
        }

        setTitle("Add a New Book");

        // Set the size of the window
        setSize(300, 200);

        // Create top panel with input fields
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5, 2));
        topPanel.add(new JLabel("Title : "));
        topPanel.add(titleText);
        topPanel.add(new JLabel("Author : "));
        topPanel.add(authText);
        topPanel.add(new JLabel("Publishing Date : "));
        topPanel.add(pubDateText);

        // Create bottom panel with the buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1, 3));
        bottomPanel.add(new JLabel("     "));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        // Add action listeners to buttons
        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        // Set layout for the window and add panels
        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        // Set window location to relative main window
        setLocationRelativeTo(mw);

        // Make the window visible
        setVisible(true);
    }

    /**
     * Handles action events for buttons.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            addBook();
        } else if (ae.getSource() == cancelBtn) {
            // Close the window when cancel is clicked
            this.setVisible(false);
        }
    }

    /**
     * Adds a new book to the library based on user input.
     */
    private void addBook() {
        try {
            // Get user input from text fields
            String title = titleText.getText();
            String author = authText.getText();
            String publicationYear = pubDateText.getText();
            String publisher = publisherText.getText(); 

            // Create and execute the AddBook Command
            Command addBook = new AddBook(title, author, publicationYear, publisher);
            addBook.execute(mw.getLibrary(), LocalDate.now());

            // Refresh the view with the list of books in the main window
            mw.displayBooks();

            // Hide (close) the AddBookWindow
            this.setVisible(false);
        } catch (LibraryException ex) {
            // Display an error message if library exception occurs
            JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
