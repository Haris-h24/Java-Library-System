package bcu.cmp5332.librarysystem.model;

import bcu.cmp5332.librarysystem.main.LibraryException;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


public class Patron {
    private int id;
    private String name;
    private String phone;
    private String email;
    private int borrowLimit = 1;  // allows each patron to borrow 1 book at a time
    private List<Book> books = new ArrayList<>();
    private boolean isDeleted;
    private boolean isHidden; 


    public Patron(int id, String name, String phone, String email, List<Book> books){
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.books = books;
    }

   

    public int getId() { //return id 
        return id;
    } 

    public String getName() { //return name
        return name;
    } 

    public String getPhone() { //return phone
        return phone;
    }

    public String getEmail() { //return email
        return email;
    }

    public int getBorrowLimit() { 
    	return borrowLimit;
    }

    public void setBorrowLimit(int limit) { 
    	this.borrowLimit = limit;
    }

    public List<Book> getBooks(Library library) { //Return the books that are currently on loan to each patron
        return library.getLoans().stream()
        		.filter(loan -> loan.getPatron().getId() == id)
        		.map(loan -> loan.getBook())
        		.collect(Collectors.toList());
    }
   

    public void setId(int id) { //set id
        this.id = id;
    }
    public String getDetailsLong() {
        

        return (
            " Patron Id:" + id + "\n" +
            " Name:" + name + "\n" +
            " Phone:" + phone + "\n" +
            " Email:" + email + "\n" 
        );
    }

    public void borrowBook(Library library, Book book, LocalDate dueDate) throws LibraryException {
        library.borrowBook(book); //calls borrowbook 
    }

    public void renewBook(Library library, Book book, LocalDate dueDate) throws LibraryException {
    	library.renewBook(book); //calls renewbook
    }

    public void returnBook(Library library, Book book) throws LibraryException {
    	library.returnBook(book); //calls returnbook
    }

    public void addBook(Library library, Book book) {
    	library.addBook(book); //calls addbook 
    }
    
    public boolean isHidden(){ // Returns isHidden
    	return isHidden;

    }
    
    public boolean isDeleted(){ // Returns isDeleted
        return isDeleted;

    }
    
    public void setHidden(boolean isHidden) { //Sets ishidden
        this.isHidden = isHidden;
    }
    
    
     
    public void setDelete(boolean isDeleted) { //Sets ishidden
        this.isDeleted = isDeleted;
    }
}