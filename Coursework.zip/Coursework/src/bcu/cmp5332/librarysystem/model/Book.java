package bcu.cmp5332.librarysystem.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * The Book class represents a book in the library.
 */
public class Book { 

    private int id;
    private String title;
    private String author;
    private String publicationYear;
    private String publisher;
    private Loan loan;
    private boolean isDeleted;
    private boolean isHidden; 
    
    
      //Constructs a Book object with the specified attributes.
     
     
    public Book(int id, String title, String author, String publicationYear, String publisher) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
    }

      // Gets the unique id of the book.
     
    public int getId() {
        return id;
    } 

    
     // Sets the unique identifier of the book.
    public void setId(int id) {
        this.id = id;
    }

    
     // Gets the title of the book.
     
    public String getTitle() {
        return title;
    }

    
     // Sets the title of the book.
     
    public void setTitle(String title) {
        this.title = title;
    }

    
     // Gets the author of the book.
     
    public String getAuthor() {
        return author;
    }

    
     // Sets the author of the book.
     
    public void setAuthor(String author) {
        this.author = author;
    }

    
     // Gets the publication year of the book.
     
    public String getPublicationYear() {
        return publicationYear;
    }

    
     // Sets the publication year of the book.
     
    public void setPublicationYear(String publicationYear) {
        this.publicationYear = publicationYear;
    }

    
     // Gets the publisher of the book.
     
    public String getPublisher() {
        return publisher;
    }

    
     // Sets the publisher of the book.
    
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    
     // Gets a short summary of the book's details.
     
    public String getDetailsShort() {
        return "Book #" + id + " - " + title;
    }

    
     // Gets a long-form representation of the book's details.
     
    public String getDetailsLong() {
        return (
            " Book Id:" + id + "\n" +
            " Title:" + title + "\n" +
            " Author:" + author + "\n" +
            " Publication Year:"	+ publicationYear + "\n" +
            " Publisher:" + publisher + "\n" +
            " Availability:" + getStatus() +"\n" +
            " Due date:" + getDueDate() + "\n"
            );
    }

    
     // Checks if the book is currently on loan.
     
    public boolean isOnLoan() {
        return (loan != null);
    }

    
     // Gets the current status of the book (On Loan or Available).
     
    public String getStatus() {
        Loan loan = getLoan();
        return isOnLoan() ? "On Loan to patron #" + loan.getPatron().getId() : "Available";
    }

    
    // Gets the due date of the book if it is on loan.
     
    public LocalDate getDueDate() {
        return getLoan() != null ? this.getLoan().getdueDate() : null;
    }
    
    
     // Checks if the book is past its due date.
     
    public boolean isPastDueDate() {
        LocalDate due = getDueDate();
        return due != null && due.compareTo(LocalDate.now()) < 0;
    }

    
     // Calculates the number of days past the book's due date.
     
    public long daysPastDueDate() {
        return this.getLoan() != null ? ChronoUnit.DAYS.between(getDueDate(), LocalDate.now()) : 0;
    }

    
     // Gets the loan associated with the book.
     
    public Loan getLoan() {
        return loan;
    }

    
     // Sets the loan associated with the book.
     
    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    
     //  returns the book to the library
     
    public void returnToLibrary() {
        loan = null;
     
    }
    public boolean isHidden(){ // Returns isHidden
    	return isHidden;

    }
    
    public boolean isDeleted(){ // Returns isDeleted
        return isDeleted;

    }
    
    public void setHidden(boolean isHidden) { //Sets ishidden
        this.isHidden = isHidden;
    }
    
    
     
    public void setDelete(boolean isDeleted) { //Sets ishidden
        this.isDeleted = isDeleted;
    }

}
