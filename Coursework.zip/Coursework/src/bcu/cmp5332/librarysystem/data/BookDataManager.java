package bcu.cmp5332.librarysystem.data;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class BookDataManager implements DataManager {

	private static final String SEPARATOR = "::";
    private static final String ID_SEPARATOR = "::";

    private final String RESOURCE = "./resources/data/books.txt"; 

    
    @Override
    
    public void loadData(Library library) throws IOException, LibraryException {
        try (Scanner sc = new Scanner(new File(RESOURCE))) {
            int line_idx = 1;
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] properties = line.split(SEPARATOR, -1);
                
                // Check if the properties array has the expected length if this is incorrect it will stop the whole project
                if (properties.length >= 5) {
                    try {
                        int id = parseBookId(properties[0]);
                        String title = properties[1];
                        String author = properties[2];
                        String publicationYear = properties[3];
                        String publisher = properties[4];
                        Book book = new Book(id, title, author, publicationYear, publisher);
                        library.addBook(book); // loads the book details
                    } catch (NumberFormatException ex) {
                        throw new LibraryException("Unable to parse book id " + properties[0] + " on line " + line_idx
                                + "\nError: " + ex); // Output upon failure to read from books.txt file
                    }
                } else {
                    throw new LibraryException("Invalid data format on line " + line_idx + ": " + line);
                }
                line_idx++;
            }
        }
    }


    private int parseBookId(String idString) {
        return Integer.parseInt(idString.split(ID_SEPARATOR)[0]);
    }

    @Override
    public void storeData(Library library) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(RESOURCE))) {
            for (Book book : library.getBooks()) {
                out.print(book.getId() + SEPARATOR);
                out.print(book.getTitle() + SEPARATOR);
                out.print(book.getAuthor() + SEPARATOR);
                out.print(book.getPublicationYear() + SEPARATOR);
                out.print(book.getPublisher() + SEPARATOR);
                out.println(); // Format of storing the book details within books.txt
            }
        } catch (IOException e) {
            // Handle IOException
        }
    }
}
