package bcu.cmp5332.librarysystem.commands;

import java.time.LocalDate;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;

public class ShowBook implements Command { // Displays a specifc book by using their id 
    private final int id;

    public ShowBook(int id) {
        this.id = id;
    }

    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Book book = library.getBookByID(id); // Getting the book details via its id
        System.out.println("ID: " + book.getId() + "\nTitle: " + book.getTitle() + "\nAuthor: " + book.getAuthor()
                + "\nPublication Year: " + book.getPublicationYear() + "\nPublisher: " + book.getPublisher()
                + "\nStatus: " + book.getStatus() + "\nDate Due: " + book.getDueDate());
        
    }
}
