package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Book;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;



     // Hides a book in the library.

public class HideBook implements Command {

    private final int id;

    
     //Creates a HideBook command for the specified book ID.
     
      
     
    public HideBook(int id) {
        this.id = id;
    }

    
     // Executes the HideBook command, hiding the specified book.
     
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Book book = library.getBookByID(id);
        if (book != null) {
            book.setHidden(true);
            System.out.println("Book Id:" + book.getId() + " is now hidden");
        } else {
            throw new LibraryException("Book with ID " + id + " not found.");
        }
    }
}
