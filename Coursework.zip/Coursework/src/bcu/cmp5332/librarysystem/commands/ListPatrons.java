package bcu.cmp5332.librarysystem.commands;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import bcu.cmp5332.librarysystem.main.LibraryException;
import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;

public class ListPatrons implements Command {

    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        List<Patron> patrons = library.getPatrons(); // gets the patron details
        for (Patron patron : patrons) { 
        	 if (patron.isHidden()) {
             	continue;
             }
            System.out.println(patron.getDetailsLong()); // Prints the long details of patrons
            System.out.println("Books on Loan:");
            System.out.println(String.join("\n", patron.getBooks(library).stream()
                    .map(book -> "   Book Id:" + book.getId() + " - " + book.getTitle())
                    .collect(Collectors.toList()))
            );
            System.out.println("----------------------------------------"); // Separator line
        }

        System.out.println(patrons.size() + " patron(s)"); // Prints the amount of patrons iin the list
    }
}
