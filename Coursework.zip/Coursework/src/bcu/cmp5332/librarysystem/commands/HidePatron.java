package bcu.cmp5332.librarysystem.commands;

import bcu.cmp5332.librarysystem.model.Library;
import bcu.cmp5332.librarysystem.model.Patron;
import bcu.cmp5332.librarysystem.main.LibraryException;

import java.time.LocalDate;


 // Hides a patron in the library.
 
public class HidePatron implements Command {

    private final int id;

    
     // Creates a HidePatron command for the specified patron ID.
     
    public HidePatron(int id) {
        this.id = id;
    }

    
     // Executes the HidePatron command, hiding the specified patron.
     
    @Override
    public void execute(Library library, LocalDate currentDate) throws LibraryException {
        Patron patron = library.getPatronByID(id);
        if (patron != null) {
            patron.setHidden(true);
            System.out.println("Patron Id:" + patron.getId() + " is now hidden");
        } else {
            throw new LibraryException("Patron with ID " + id + " not found.");
        }
    }
}
